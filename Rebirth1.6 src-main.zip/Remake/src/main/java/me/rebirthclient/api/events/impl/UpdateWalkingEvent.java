package me.rebirthclient.api.events.impl;

import me.rebirthclient.api.events.Event;

public class UpdateWalkingEvent extends Event {
    public UpdateWalkingEvent(Stage stage) {
        super(stage);
    }
}
