package me.rebirthclient.api.interfaces;

public interface IChatHudLine {
    int rebirth_nextgen_master$getId();
    void rebirth_nextgen_master$setId(int id);
}
