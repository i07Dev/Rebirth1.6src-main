package me.rebirthclient.api.interfaces;

import net.minecraft.client.gl.Framebuffer;

public interface IShaderEffect {
    void rebirth_nextgen_master$addFakeTargetHook(String name, Framebuffer buffer);
}