package me.rebirthclient.api.interfaces;

import net.minecraft.text.Text;

public interface IChatHud {
    void rebirth_nextgen_master$add(Text message, int id);
}
