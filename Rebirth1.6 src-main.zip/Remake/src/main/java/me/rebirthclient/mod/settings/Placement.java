package me.rebirthclient.mod.settings;

public enum Placement {
    Vanilla,
    Strict,
    Legit,
    AirPlace
}
