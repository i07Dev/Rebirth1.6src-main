/*
 * Decompiled with CFR 0.150.
 */
package me.rebirthclient.mod.modules.miscellaneous;

import me.rebirthclient.mod.modules.Module;

public class ShulkerViewer
extends Module {
    public static ShulkerViewer INSTANCE;

    public ShulkerViewer() {
        super("ShulkerViewer", Module.Category.Miscellaneous);
        INSTANCE = this;
    }
}

