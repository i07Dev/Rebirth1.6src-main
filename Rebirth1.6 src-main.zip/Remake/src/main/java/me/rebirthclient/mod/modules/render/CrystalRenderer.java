/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.decoration.EndCrystalEntity
 *  net.minecraft.util.math.Vec3d
 */
package me.rebirthclient.mod.modules.render;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Random;
import me.rebirthclient.mod.modules.Module;
import me.rebirthclient.mod.settings.impl.BooleanSetting;
import me.rebirthclient.mod.settings.impl.SliderSetting;
import net.minecraft.entity.Entity;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.util.math.Vec3d;

public class CrystalRenderer
extends Module {
    public static CrystalRenderer INSTANCE;
    public static HashMap<EndCrystalEntity, Double> spinMap;
    public static HashMap<Vec3d, Double> posSpinMap;
    public static HashMap<EndCrystalEntity, Double> floatMap;
    public static HashMap<Vec3d, Double> posFloatMap;
    public static Random random;
    public BooleanSetting sync = this.add(new BooleanSetting("Sync", true));
    public final SliderSetting spinAdd = this.add(new SliderSetting("SpinNewAdd", 0.0, 0.0, 100.0, 1.0, v -> this.sync.getValue()));
    public final SliderSetting spinValue = this.add(new SliderSetting("SpinSpeed", 1.0, 0.0, 3.0, 0.01));
    public final SliderSetting floatValue = this.add(new SliderSetting("FloatSpeed", 1.0, 0.0, 3.0, 0.01));
    public final SliderSetting floatOffset = this.add(new SliderSetting("FloatOffset", 0.0, -1.0, 1.0, 0.01));

    public CrystalRenderer() {
        super("CrystalRenderer", Module.Category.Render);
        INSTANCE = this;
    }

    @Override
    public void onUpdate() {
        if (!this.sync.getValue()) {
            return;
        }
        ArrayList<EndCrystalEntity> noSpinAge = new ArrayList<EndCrystalEntity>();
        ArrayList<EndCrystalEntity> noFloatAge = new ArrayList<EndCrystalEntity>();
        for (Entity entity : CrystalRenderer.mc.world.getEntities()) {
            if (!(entity instanceof EndCrystalEntity)) continue;
            EndCrystalEntity crystal = (EndCrystalEntity)entity;
            if (spinMap.getOrDefault((Object)crystal, -1.0) != -1.0) {
                spinMap.put(crystal, spinMap.get((Object)crystal) + 1.0);
                posSpinMap.put(crystal.getPos(), spinMap.get((Object)crystal));
            } else {
                noSpinAge.add(crystal);
            }
            if (floatMap.getOrDefault((Object)crystal, -1.0) != -1.0) {
                floatMap.put(crystal, floatMap.get((Object)crystal) + 1.0);
                posFloatMap.put(crystal.getPos(), floatMap.get((Object)crystal));
                continue;
            }
            noFloatAge.add(crystal);
        }
        for (EndCrystalEntity crystal : noSpinAge) {
            if (spinMap.getOrDefault((Object)crystal, -1.0) != -1.0) continue;
            spinMap.put(crystal, posSpinMap.getOrDefault((Object)crystal.getPos(), Double.valueOf(random.nextInt(10000))) + this.spinAdd.getValue());
        }
        for (EndCrystalEntity crystal : noFloatAge) {
            if (floatMap.getOrDefault((Object)crystal, -1.0) != -1.0) continue;
            floatMap.put(crystal, posFloatMap.getOrDefault((Object)crystal.getPos(), Double.valueOf(random.nextInt(10000))));
        }
    }

    public double getSpinAge(EndCrystalEntity crystal) {
        double age;
        if (!this.sync.getValue()) {
            return crystal.endCrystalAge;
        }
        if (spinMap.getOrDefault((Object)crystal, -1.0) == -1.0) {
            spinMap.put(crystal, posSpinMap.getOrDefault((Object)crystal.getPos(), Double.valueOf(random.nextInt(10000))) + this.spinAdd.getValue());
        }
        if ((age = spinMap.getOrDefault((Object)crystal, posSpinMap.getOrDefault((Object)crystal.getPos(), -1.0)).doubleValue()) != -1.0) {
            return age;
        }
        age = random.nextInt(10000);
        posSpinMap.put(crystal.getPos(), age);
        return age;
    }

    public double getFloatAge(EndCrystalEntity crystal) {
        double age;
        if (!this.sync.getValue()) {
            return crystal.endCrystalAge;
        }
        if (floatMap.getOrDefault((Object)crystal, -1.0) == -1.0) {
            floatMap.put(crystal, posFloatMap.getOrDefault((Object)crystal.getPos(), Double.valueOf(random.nextInt(10000))));
        }
        if ((age = floatMap.getOrDefault((Object)crystal, posFloatMap.getOrDefault((Object)crystal.getPos(), -1.0)).doubleValue()) != -1.0) {
            return age;
        }
        age = random.nextInt(10000);
        posFloatMap.put(crystal.getPos(), age);
        return age;
    }

    static {
        spinMap = new HashMap();
        posSpinMap = new HashMap();
        floatMap = new HashMap();
        posFloatMap = new HashMap();
        random = new Random();
    }
}

