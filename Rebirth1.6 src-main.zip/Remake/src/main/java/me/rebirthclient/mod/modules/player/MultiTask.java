/*
 * Decompiled with CFR 0.150.
 */
package me.rebirthclient.mod.modules.player;

import me.rebirthclient.mod.modules.Module;

public class MultiTask
extends Module {
    public static MultiTask INSTANCE;

    public MultiTask() {
        super("MultiTask", Module.Category.Player);
        INSTANCE = this;
    }
}

