/*
 * Decompiled with CFR 0.150.
 */
package me.rebirthclient.mod.modules.render;

import me.rebirthclient.mod.modules.Module;

public class NoInvisible
extends Module {
    public static NoInvisible INSTANCE;

    public NoInvisible() {
        super("NoInvisible", Module.Category.Render);
        INSTANCE = this;
    }
}

